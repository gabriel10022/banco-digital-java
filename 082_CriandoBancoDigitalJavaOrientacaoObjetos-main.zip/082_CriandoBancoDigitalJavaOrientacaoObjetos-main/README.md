# LABs

## 082_CriandoBancoDigitalJavaOrientacaoObjetos

Criando um Banco Digital com Java e Orientação a Objetos

Reforce seu conhecimento em Programação Orientada a Objetos (POO) em Java com um desafio de projeto totalmente prático. Para isso, os pilares da orientação a objetos são devidamente explorados no contexto bancário, onde o expert implementa um projeto de referência (disponibilizado no GitHub) de forma prática e interativa. Sendo assim, você poderá desenvolver sua capacidade de abstração reproduzindo essa solução. Além disso, caso queira ir além, implemente suas próprias evoluções e melhorias ;-)

Java - Full-Stack - Intermediário
ESPECIALISTA
#### Venilton FalvoJr
Tech Lead, Digital Innovation One

https://web.dio.me/lab/criando-um-banco-digital-com-java-e-orientacao-objetos/learning/7fce6cb4-f125-4fec-8927-435eec7c89eb
